<?
//this is a test

include("blah.php");

/**
 * This is a test of the wsdl generator
 *
 * @return	string	output of a test
 */

function blah()
{
}


/**
* Test description.
*
* anything said here
*/
class blah_test
{
	/**
	* Test description.
	*
	* anything said here
	*
	* @return array will return an array in the form:
	* <pre>
	* 0 => 10
	* 1 => 20
	* </pre>
	*/
	var $my_var;
	
	function blah_test()
	{
	}
	
	function test1()
	{
	}
}
?>
